<template>
  <div id="download-excel">
      <el-button type="primary" @click="downloadExcel">点击下载</el-button>
</div>
</template>

<script>
import FileSaver from 'file-saver'
import XLSX from 'xlsx'
export default {
  
}
</script>