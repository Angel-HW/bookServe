<template>
  <div id="book-out">
    <span>这是图书出库页面</span>
  </div>
</template>
