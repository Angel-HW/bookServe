<template>
  <div id="book-in">
    <span>这是图书入库页面</span>
  </div>
</template>
