<template>
  <div id="admin-info">
    <span>这是管理人员页面</span>
  </div>
</template>
