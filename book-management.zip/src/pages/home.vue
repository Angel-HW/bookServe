<template>
  <div id="home">
    <el-container class="first-container">
      <el-aside width="200px">
        <div class="logo">
          <h1>第三组</h1>
        </div>
        <!-- 管理员菜单 -->
        <div class="menu">
          <el-menu router :default-active="defaultUrl">
            <el-submenu index="1">
              <template slot="title"><i class="el-icon-reading"></i>图书管理</template>
              <el-menu-item-group>
                <template slot="title">子菜单</template>
                <el-menu-item index="/bookPurchar">图书采购</el-menu-item>
                <el-menu-item index="/bookOut">图书入库</el-menu-item>
                <el-menu-item index="/bookIn">图书出库</el-menu-item>
                <el-menu-item index="/bookSearch">图书查询</el-menu-item>
                <el-menu-item index="/bookBorrow">图书借阅wo</el-menu-item>
                <el-menu-item index="/bookReturn">图书归还wo</el-menu-item>
                <el-menu-item index="/bookBRSearch">借阅图书查询</el-menu-item>
                <el-menu-item index="/test">测试</el-menu-item>
              </el-menu-item-group>
            </el-submenu>
            <el-submenu index="2">
              <template slot="title"><i class="el-icon-user-solid"></i>用户管理</template>
              <el-menu-item-group>
                <template slot="title">子菜单</template>
                <el-menu-item index="/adminInfo">用户信息wo</el-menu-item>
              </el-menu-item-group>
            </el-submenu>
          </el-menu>
        </div>
      </el-aside>

      <el-container class="second-container">
        <el-header>
          <span>管理员</span>
        </el-header>
        <el-main>
          <router-view/>
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<script>
export default {
  name: 'home',
  data () {
    return {
      defaultUrl: ''
    }
  },
  computed: {
    userType () {
      // return JSON.parse(sessionStorage.getItem('roleInfo')).role
      return '1'
    }
  },
  mounted () {
    const href = window.location.href
    this.defaultUrl = href.split('/#')[1]
  }
}
</script>

<style lang="scss">
#home {
  .first-container {
    height: 100vh;
    // border: 1px solid #eee;
    .el-aside {
      color: white;
      background-color: rgb(42, 58, 76);
      .logo {
        width: 200px;
        height: 60px;
        text-align: center;
        line-height: 60px;
        h1 {
          border-right: 1px solid #ffffff;
          margin: 0;
        }
      }
      .menu {
        .el-menu {
          background-color: rgb(42, 58, 76);
          .el-submenu {
            border-top: 1px solid #dddddd;
            .el-submenu__title {
              color: white;
            }
            .el-submenu__title:hover {
              background-color: rgb(0, 21, 40)!important;
            }
            .el-menu-item-group {
              background-color: rgb(31, 45, 61);
              .el-menu-item {
                color: white;
              }
              .el-menu-item.is-active {
                color: #1890ff!important;
              }
              .el-menu-item:hover {
                background-color: rgb(0, 21, 40)!important;
              }
              .el-menu-item:focus {
                background-color: rgb(0, 21, 40)!important;
              }
            }
          }
        }
      }
    }
    .second-container {
      .el-header {
        background-color: #ffffff;
        color: #333;
        line-height: 60px;
        text-align: right;
        font-size: 12px
      }
      .el-main {
        background-color: #dddddd;
      }
    }
  }
}
</style>
