<template>
  <div id="register">
    <div class="box">
      <el-image :src="require('../login/loginlogo.jpeg')"></el-image>
      <el-form :model="form">
        <h2>注册</h2>
        <el-form-item label="用户名">
          <el-input v-model="form.name"></el-input>
        </el-form-item>
        <el-form-item label="密码">
          <el-input v-model="form.passWord"></el-input>
        </el-form-item>
        <el-form-item label="确认密码">
          <el-input v-model="form.comfirmPassWord"></el-input>
        </el-form-item>
        <el-form-item label="手机号">
          <el-input v-model="form.phone"></el-input>
        </el-form-item>
        <el-form-item label="邮箱">
          <el-input v-model="form.email"></el-input>
        </el-form-item>
        <el-form-item class="identifyCode">
          <el-image :src="identifyCode" @click="getIdenfyCode()"></el-image>
        </el-form-item>
        <el-form-item label="验证码">
          <el-input v-model="form.indentifyCode"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary">注册</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script>
export default {
  name: 'register',
  data () {
    return {
      form: {
        name: '',
        passWord: '',
        comfirmPassWord: '',
        phone: '',
        email: '',
        indentifyCode: ''
      }
    }
  }
}
</script>

<style lang="scss">
#register {
  height: 100vh;
  background-color: rgb(53, 147, 207);
  .box {
    display: flex;
    justify-content: center;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 45%;
    // height: 500px;
    box-shadow: 10px 10px 10px 10px #000000;
    .el-image {
      width: 35%;
    }
    .el-form {
      flex: 1;
      border: 1px solid #dddddd;
      padding: 30px 0;
      background-color: #fff;
      h2 {
        text-align: center;
        margin: 0;
      }
      .identifyCode {
        padding-left: 70px;
        .el-form-item__content{
          display: flex;
          justify-content: center;
          align-items: center;
        }
      }
      .el-form-item {
        display: flex;
        margin: 20px auto;
        .el-form-item__label {
          width: 70px;
        }
        .el-form-item__content {
          width: 70%;
        }
      }
      .el-form-item:last-child {
        display: flex;
        justify-content: center;
        .el-button {
          width: 90%;
        }
      }
    }
  }
}
</style>
